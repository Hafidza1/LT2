<footer class="main-footer">
    <div class="pull-right hidden-xs">
      Page rendered in {elapsed_time} seconds - 
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; <?= date('Y');?> <a href="#">Kelompok 6</a>.</strong> All rights
    reserved.
  </footer>

</div>
<!-- ./wrapper -->


<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<!-- <script>
  $.widget.bridge('uibutton', $.ui.button);
</script> -->
<!-- Bootstrap 3.3.7 -->
<script src="<?= base_url('./../assets/adminlte/bower_components/bootstrap/dist/js/bootstrap.min.js');?>"></script>
<!-- jQuery Knob Chart -->
<!-- <script src="<?= base_url('./../assets/adminlte/bower_components/jquery-knob/dist/jquery.knob.min.js');?>"></script> -->
<!-- daterangepicker -->
<!-- <script src="<?= base_url('./../assets/adminlte/bower_components/moment/min/moment.min.js');?>"></script>
<script src="<?= base_url('./../assets/adminlte/bower_components/bootstrap-daterangepicker/daterangepicker.js');?>"></script> -->
<!-- datepicker -->
<script src="<?= base_url('./../assets/adminlte/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js');?>"></script>
<!-- Bootstrap WYSIHTML5 -->
<!-- <script src="<?= base_url('./../assets/adminlte/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js');?>"></script> -->
<!-- Select2 -->
<!-- <script src="<?=base_url('./../assets/adminlte/bower_components/select2/dist/js/select2.full.min.js');?>"></script> -->
<!-- Slimscroll -->
<script src="<?= base_url('./../assets/adminlte/bower_components/jquery-slimscroll/jquery.slimscroll.min.js');?>"></script>
<!-- FastClick -->
<script src="<?= base_url('./../assets/adminlte/bower_components/fastclick/lib/fastclick.js');?>"></script>
<!-- AdminLTE App -->
<script src="<?= base_url('./../assets/adminlte/dist/js/adminlte.min.js');?>"></script>
</body>
</html>
